# ============================================================
#   Inventory Management System
#   Alliance University – Alliance College of Engineering and Design
#   Course  : Programming in Python
#   Team    :
#       1. L. Navaneesh Reddy
#       2. Mohit
#       3. Chrysolite
#       4. Pavan R
#       5. Sai Sathwik
# ============================================================

import sqlite3
import csv
import os

DB_FILE = os.path.join(os.path.dirname(__file__), "..", "inventory.db")


# ─────────────────────────────────────────────
#  DATABASE  SETUP
# ─────────────────────────────────────────────
def get_connection():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def initialize_db():
    conn = get_connection()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS items (
            item_id       TEXT PRIMARY KEY,
            name          TEXT NOT NULL,
            category      TEXT NOT NULL,
            quantity      INTEGER NOT NULL,
            price         REAL NOT NULL,
            supplier      TEXT NOT NULL,
            min_stock     INTEGER NOT NULL
        )
    """)
    conn.commit()
    # Seed sample data on first run
    if conn.execute("SELECT COUNT(*) FROM items").fetchone()[0] == 0:
        sample = [
            ("ITM001", "Rice (1 kg)",     "Food",        50, 60.00,  "AgroSupplies",    10),
            ("ITM002", "USB Cable",        "Electronics", 30, 150.00, "TechMart",        5),
            ("ITM003", "Notebook",         "Stationery",  20, 40.00,  "PaperWorld",      5),
            ("ITM004", "Hand Sanitizer",   "Healthcare",   8, 90.00,  "MediStore",       10),
            ("ITM005", "Pen (Blue, 10pk)", "Stationery",   3, 25.00,  "PaperWorld",      10),
        ]
        conn.executemany(
            "INSERT INTO items VALUES (?,?,?,?,?,?,?)", sample
        )
        conn.commit()
    conn.close()


# ─────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────
def print_header(title):
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)


def print_table(rows):
    if not rows:
        print("  (no records found)")
        return
    print(f"\n  {'ID':<8} {'Name':<22} {'Category':<14} {'Qty':>5} {'Price':>8} {'Supplier':<16} {'Min':>4}")
    print("  " + "-" * 85)
    for r in rows:
        alert = " ⚠ LOW" if r["quantity"] <= r["min_stock"] else ""
        print(f"  {r['item_id']:<8} {r['name']:<22} {r['category']:<14} "
              f"{r['quantity']:>5} {r['price']:>8.2f} {r['supplier']:<16} {r['min_stock']:>4}{alert}")
    print()


def input_int(prompt, min_val=0):
    while True:
        try:
            val = int(input(prompt))
            if val < min_val:
                print(f"  Value must be >= {min_val}. Try again.")
                continue
            return val
        except ValueError:
            print("  Please enter a whole number.")


def input_float(prompt, min_val=0.0):
    while True:
        try:
            val = float(input(prompt))
            if val < min_val:
                print(f"  Value must be >= {min_val}. Try again.")
                continue
            return val
        except ValueError:
            print("  Please enter a valid number.")


# ─────────────────────────────────────────────
#  CRUD  OPERATIONS
# ─────────────────────────────────────────────
def add_item():
    print_header("ADD NEW ITEM")
    conn = get_connection()

    item_id = input("  Enter Item ID (e.g. ITM006): ").strip().upper()
    if not item_id:
        print("  Item ID cannot be empty.")
        conn.close(); return

    exists = conn.execute("SELECT 1 FROM items WHERE item_id=?", (item_id,)).fetchone()
    if exists:
        print(f"  Item ID '{item_id}' already exists. Use a different ID.")
        conn.close(); return

    name     = input("  Item Name          : ").strip()
    category = input("  Category           : ").strip()
    quantity = input_int("  Quantity           : ", min_val=0)
    price    = input_float("  Unit Price (₹)     : ", min_val=0.01)
    supplier = input("  Supplier Name      : ").strip()
    min_stock= input_int("  Minimum Stock Level: ", min_val=0)

    conn.execute(
        "INSERT INTO items VALUES (?,?,?,?,?,?,?)",
        (item_id, name, category, quantity, price, supplier, min_stock)
    )
    conn.commit()
    conn.close()
    print(f"\n  ✅  Item '{name}' added successfully!")


def view_all_items():
    print_header("ALL INVENTORY ITEMS")
    conn = get_connection()
    rows = conn.execute("SELECT * FROM items ORDER BY category, name").fetchall()
    conn.close()
    print_table(rows)
    print(f"  Total items: {len(rows)}")


def search_item():
    print_header("SEARCH ITEM")
    keyword = input("  Enter Item ID or Name to search: ").strip()
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM items WHERE item_id LIKE ? OR name LIKE ?",
        (f"%{keyword}%", f"%{keyword}%")
    ).fetchall()
    conn.close()
    print_table(rows)


def update_item():
    print_header("UPDATE ITEM")
    view_all_items()
    item_id = input("  Enter Item ID to update: ").strip().upper()
    conn = get_connection()
    row = conn.execute("SELECT * FROM items WHERE item_id=?", (item_id,)).fetchone()
    if not row:
        print(f"  Item '{item_id}' not found.")
        conn.close(); return

    print(f"\n  Updating: {row['name']}  (current qty: {row['quantity']}, price: ₹{row['price']:.2f})")
    print("  Press ENTER to keep current value.\n")

    name      = input(f"  Name     [{row['name']}]: ").strip() or row["name"]
    category  = input(f"  Category [{row['category']}]: ").strip() or row["category"]
    qty_str   = input(f"  Quantity [{row['quantity']}]: ").strip()
    quantity  = int(qty_str) if qty_str.isdigit() else row["quantity"]
    price_str = input(f"  Price    [{row['price']}]: ").strip()
    try:
        price = float(price_str) if price_str else row["price"]
    except ValueError:
        price = row["price"]
    supplier  = input(f"  Supplier [{row['supplier']}]: ").strip() or row["supplier"]
    min_str   = input(f"  Min Stock[{row['min_stock']}]: ").strip()
    min_stock = int(min_str) if min_str.isdigit() else row["min_stock"]

    conn.execute(
        "UPDATE items SET name=?, category=?, quantity=?, price=?, supplier=?, min_stock=? WHERE item_id=?",
        (name, category, quantity, price, supplier, min_stock, item_id)
    )
    conn.commit()
    conn.close()
    print(f"\n  ✅  Item '{item_id}' updated successfully!")


def delete_item():
    print_header("DELETE ITEM")
    view_all_items()
    item_id = input("  Enter Item ID to delete: ").strip().upper()
    conn = get_connection()
    row = conn.execute("SELECT * FROM items WHERE item_id=?", (item_id,)).fetchone()
    if not row:
        print(f"  Item '{item_id}' not found.")
        conn.close(); return

    confirm = input(f"  Delete '{row['name']}'? Type YES to confirm: ").strip()
    if confirm.upper() == "YES":
        conn.execute("DELETE FROM items WHERE item_id=?", (item_id,))
        conn.commit()
        print(f"\n  ✅  Item '{item_id}' deleted.")
    else:
        print("  Deletion cancelled.")
    conn.close()


# ─────────────────────────────────────────────
#  REPORTS  &  ALERTS
# ─────────────────────────────────────────────
def low_stock_alert():
    print_header("LOW STOCK ALERT")
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM items WHERE quantity <= min_stock ORDER BY quantity"
    ).fetchall()
    conn.close()
    if not rows:
        print("  ✅  All items are adequately stocked.")
    else:
        print(f"  ⚠  {len(rows)} item(s) need restocking:\n")
        print_table(rows)


def stock_valuation():
    print_header("TOTAL STOCK VALUATION")
    conn = get_connection()
    rows = conn.execute("SELECT * FROM items ORDER BY category").fetchall()
    conn.close()

    category_totals = {}
    grand_total = 0.0
    for r in rows:
        val = r["quantity"] * r["price"]
        grand_total += val
        category_totals[r["category"]] = category_totals.get(r["category"], 0) + val

    print(f"\n  {'Category':<20} {'Value (₹)':>12}")
    print("  " + "-" * 35)
    for cat, val in sorted(category_totals.items()):
        print(f"  {cat:<20} {val:>12.2f}")
    print("  " + "-" * 35)
    print(f"  {'GRAND TOTAL':<20} {grand_total:>12.2f}")
    print()


def category_summary():
    print_header("CATEGORY-WISE SUMMARY")
    conn = get_connection()
    rows = conn.execute("""
        SELECT category,
               COUNT(*) AS items,
               SUM(quantity) AS total_qty,
               ROUND(SUM(quantity * price), 2) AS total_value
        FROM items
        GROUP BY category
        ORDER BY category
    """).fetchall()
    conn.close()

    print(f"\n  {'Category':<18} {'Items':>5} {'Total Qty':>10} {'Value (₹)':>12}")
    print("  " + "-" * 50)
    for r in rows:
        print(f"  {r['category']:<18} {r['items']:>5} {r['total_qty']:>10} {r['total_value']:>12.2f}")
    print()


def export_to_csv():
    print_header("EXPORT TO CSV")
    filename = os.path.join(os.path.dirname(__file__), "..", "inventory_export.csv")
    conn = get_connection()
    rows = conn.execute("SELECT * FROM items").fetchall()
    conn.close()

    with open(filename, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Item ID", "Name", "Category", "Quantity", "Price", "Supplier", "Min Stock"])
        for r in rows:
            writer.writerow([r["item_id"], r["name"], r["category"],
                             r["quantity"], r["price"], r["supplier"], r["min_stock"]])
    print(f"\n  ✅  Exported {len(rows)} records to:\n  {os.path.abspath(filename)}\n")


# ─────────────────────────────────────────────
#  MAIN  MENU
# ─────────────────────────────────────────────
MENU = """
╔══════════════════════════════════════════════╗
║      INVENTORY MANAGEMENT SYSTEM             ║
║      Alliance University – Python Project    ║
╠══════════════════════════════════════════════╣
║  1. Add New Item                             ║
║  2. View All Items                           ║
║  3. Search Item                              ║
║  4. Update Item                              ║
║  5. Delete Item                              ║
║──────────────────────────────────────────────║
║  6. Low Stock Alerts                         ║
║  7. Total Stock Valuation                    ║
║  8. Category-wise Summary                    ║
║  9. Export Inventory to CSV                  ║
║──────────────────────────────────────────────║
║  0. Exit                                     ║
╚══════════════════════════════════════════════╝
  Choose an option: """

ACTIONS = {
    "1": add_item,
    "2": view_all_items,
    "3": search_item,
    "4": update_item,
    "5": delete_item,
    "6": low_stock_alert,
    "7": stock_valuation,
    "8": category_summary,
    "9": export_to_csv,
}


def main():
    initialize_db()
    print("\n  Welcome to the Inventory Management System!")
    print("  Team: Navaneesh Reddy | Mohit | Chrysolite | Pavan R | Sai Sathwik")
    while True:
        choice = input(MENU).strip()
        if choice == "0":
            print("\n  Thank you! Goodbye.\n")
            break
        action = ACTIONS.get(choice)
        if action:
            action()
        else:
            print("  Invalid option. Please choose 0–9.")


if __name__ == "__main__":
    main()
