# Inventory Management System

**Alliance University – Alliance College of Engineering and Design**  
Course: Programming in Python | Micro-Project

---

## Team Members

| # | Name |
|---|------|
| 1 | L. Navaneesh Reddy |
| 2 | Mohit |
| 3 | Chrysolite |
| 4 | Pavan R |
| 5 | Sai Sathwik |

---

## How to Run on GitHub (No Install Needed)

### Step 1 — Open in GitHub Codespaces
Click the green **Code** button on your repo → **Codespaces** tab → **Create codespace on main**

This opens a VS Code terminal in your browser.

### Step 2 — Run the program
Type this in the terminal and press Enter:

```
python inventory.py
```

That's it! The program starts immediately.

---

## How to Run on Your Laptop

```bash
python inventory.py
```

No extra libraries needed. Python 3 only.

---

## Features

| # | Feature | Description |
|---|---------|-------------|
| 1 | Add Item | Add new product with all details |
| 2 | View All | Display full inventory table |
| 3 | Search | Find item by ID or name |
| 4 | Update | Edit any item's details |
| 5 | Delete | Remove item (with confirmation) |
| 6 | Low Stock Alert | Shows items below minimum level |
| 7 | Stock Valuation | Total value of all inventory |
| 8 | Category Summary | Category-wise breakdown |
| 9 | Export CSV | Save inventory to spreadsheet |

---

## Technologies Used

- Python 3
- SQLite3 (built into Python — no install needed)
- CSV module (built into Python)

---

## Project Description

This Inventory Management System implements CRUD operations (Create, Read, Update, Delete) using Python and SQLite. It includes business logic for low-stock alerts, stock valuation, and CSV export — mirroring features found in commercial ERP systems like SAP and Tally.

---

## File Structure

```
inventory-management-system/
├── inventory.py        ← main program (run this)
├── inventory.db        ← auto-created SQLite database
├── inventory_export.csv← generated when you export
└── README.md
```
