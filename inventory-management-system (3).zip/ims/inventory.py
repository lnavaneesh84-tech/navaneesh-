# ============================================================
#   Inventory Management System
#   Alliance University - Alliance College of Engineering and Design
#   Course  : Programming in Python
#
#   Team Members:
#       1. L. Navaneesh Reddy
#       2. Mohit
#       3. Chrysolite
#       4. Pavan R
#       5. Sai Sathwik
# ============================================================

import sqlite3
import csv
import os

DB_FILE = "inventory.db"

# ──────────────────────────────────────────────
#  DATABASE SETUP
# ──────────────────────────────────────────────
def init_db():
    conn = sqlite3.connect(DB_FILE)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS items (
            item_id     TEXT PRIMARY KEY,
            name        TEXT NOT NULL,
            category    TEXT NOT NULL,
            quantity    INTEGER NOT NULL,
            price       REAL NOT NULL,
            supplier    TEXT NOT NULL,
            min_stock   INTEGER NOT NULL
        )
    """)
    conn.commit()
    # Add sample data on first run
    if conn.execute("SELECT COUNT(*) FROM items").fetchone()[0] == 0:
        sample = [
            ("ITM001", "Rice (1 kg)",      "Food",        50,  60.00, "AgroSupplies", 10),
            ("ITM002", "USB Cable",         "Electronics", 30, 150.00, "TechMart",      5),
            ("ITM003", "Notebook",          "Stationery",  20,  40.00, "PaperWorld",    5),
            ("ITM004", "Hand Sanitizer",    "Healthcare",   8,  90.00, "MediStore",    10),
            ("ITM005", "Pen (Blue, 10pk)",  "Stationery",   3,  25.00, "PaperWorld",   10),
        ]
        conn.executemany("INSERT INTO items VALUES (?,?,?,?,?,?,?)", sample)
        conn.commit()
        print("\n  Sample data loaded into database.")
    conn.close()

def get_conn():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

# ──────────────────────────────────────────────
#  DISPLAY HELPERS
# ──────────────────────────────────────────────
def header(title):
    print("\n" + "=" * 65)
    print(f"   {title}")
    print("=" * 65)

def print_table(rows):
    if not rows:
        print("\n  No records found.\n")
        return
    print(f"\n  {'ID':<8} {'Name':<22} {'Category':<13} {'Qty':>5} {'Price (Rs)':>10} {'Supplier':<14} {'Min':>4}")
    print("  " + "-" * 80)
    for r in rows:
        flag = "  << LOW STOCK" if r["quantity"] <= r["min_stock"] else ""
        print(f"  {r['item_id']:<8} {r['name']:<22} {r['category']:<13} "
              f"{r['quantity']:>5} {r['price']:>10.2f} {r['supplier']:<14} {r['min_stock']:>4}{flag}")
    print()

def get_int(prompt, min_val=0):
    while True:
        try:
            v = int(input(prompt))
            if v < min_val:
                print(f"  Must be >= {min_val}.")
            else:
                return v
        except ValueError:
            print("  Enter a whole number.")

def get_float(prompt):
    while True:
        try:
            v = float(input(prompt))
            if v < 0:
                print("  Must be >= 0.")
            else:
                return v
        except ValueError:
            print("  Enter a valid number.")

# ──────────────────────────────────────────────
#  1. ADD ITEM
# ──────────────────────────────────────────────
def add_item():
    header("ADD NEW ITEM")
    conn = get_conn()

    item_id = input("  Item ID        : ").strip().upper()
    if not item_id:
        print("  Item ID cannot be empty.")
        conn.close(); return
    if conn.execute("SELECT 1 FROM items WHERE item_id=?", (item_id,)).fetchone():
        print(f"  Item ID '{item_id}' already exists.")
        conn.close(); return

    name      = input("  Name           : ").strip()
    category  = input("  Category       : ").strip()
    quantity  = get_int("  Quantity       : ")
    price     = get_float("  Price (Rs)     : ")
    supplier  = input("  Supplier       : ").strip()
    min_stock = get_int("  Min Stock Level: ")

    conn.execute("INSERT INTO items VALUES (?,?,?,?,?,?,?)",
                 (item_id, name, category, quantity, price, supplier, min_stock))
    conn.commit()
    conn.close()
    print(f"\n  [OK] '{name}' added successfully!")

# ──────────────────────────────────────────────
#  2. VIEW ALL ITEMS
# ──────────────────────────────────────────────
def view_all():
    header("ALL INVENTORY ITEMS")
    conn = get_conn()
    rows = conn.execute("SELECT * FROM items ORDER BY category, name").fetchall()
    conn.close()
    print_table(rows)
    print(f"  Total items: {len(rows)}")

# ──────────────────────────────────────────────
#  3. SEARCH ITEM
# ──────────────────────────────────────────────
def search_item():
    header("SEARCH ITEM")
    keyword = input("  Search (ID or name): ").strip()
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM items WHERE item_id LIKE ? OR name LIKE ?",
        (f"%{keyword}%", f"%{keyword}%")
    ).fetchall()
    conn.close()
    print_table(rows)

# ──────────────────────────────────────────────
#  4. UPDATE ITEM
# ──────────────────────────────────────────────
def update_item():
    header("UPDATE ITEM")
    view_all()
    item_id = input("  Enter Item ID to update: ").strip().upper()
    conn = get_conn()
    row = conn.execute("SELECT * FROM items WHERE item_id=?", (item_id,)).fetchone()
    if not row:
        print(f"  Item '{item_id}' not found.")
        conn.close(); return

    print(f"\n  Updating: {row['name']}  |  Qty: {row['quantity']}  |  Price: Rs {row['price']:.2f}")
    print("  (Press ENTER to keep current value)\n")

    name     = input(f"  Name      [{row['name']}]: ").strip() or row["name"]
    category = input(f"  Category  [{row['category']}]: ").strip() or row["category"]

    qty_in = input(f"  Quantity  [{row['quantity']}]: ").strip()
    quantity = int(qty_in) if qty_in.isdigit() else row["quantity"]

    price_in = input(f"  Price     [{row['price']}]: ").strip()
    try:
        price = float(price_in) if price_in else row["price"]
    except ValueError:
        price = row["price"]

    supplier  = input(f"  Supplier  [{row['supplier']}]: ").strip() or row["supplier"]
    min_in    = input(f"  Min Stock [{row['min_stock']}]: ").strip()
    min_stock = int(min_in) if min_in.isdigit() else row["min_stock"]

    conn.execute("""UPDATE items SET name=?,category=?,quantity=?,price=?,supplier=?,min_stock=?
                    WHERE item_id=?""",
                 (name, category, quantity, price, supplier, min_stock, item_id))
    conn.commit()
    conn.close()
    print(f"\n  [OK] Item '{item_id}' updated successfully!")

# ──────────────────────────────────────────────
#  5. DELETE ITEM
# ──────────────────────────────────────────────
def delete_item():
    header("DELETE ITEM")
    view_all()
    item_id = input("  Enter Item ID to delete: ").strip().upper()
    conn = get_conn()
    row = conn.execute("SELECT * FROM items WHERE item_id=?", (item_id,)).fetchone()
    if not row:
        print(f"  Item '{item_id}' not found.")
        conn.close(); return
    confirm = input(f"  Delete '{row['name']}'? Type YES to confirm: ").strip()
    if confirm.upper() == "YES":
        conn.execute("DELETE FROM items WHERE item_id=?", (item_id,))
        conn.commit()
        print(f"\n  [OK] '{item_id}' deleted.")
    else:
        print("  Cancelled.")
    conn.close()

# ──────────────────────────────────────────────
#  6. LOW STOCK ALERTS
# ──────────────────────────────────────────────
def low_stock_alert():
    header("LOW STOCK ALERT")
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM items WHERE quantity <= min_stock ORDER BY quantity"
    ).fetchall()
    conn.close()
    if not rows:
        print("\n  [OK] All items are adequately stocked.\n")
    else:
        print(f"\n  WARNING: {len(rows)} item(s) need restocking!\n")
        print_table(rows)

# ──────────────────────────────────────────────
#  7. STOCK VALUATION
# ──────────────────────────────────────────────
def stock_valuation():
    header("TOTAL STOCK VALUATION")
    conn = get_conn()
    rows = conn.execute("SELECT * FROM items").fetchall()
    conn.close()

    cat_totals = {}
    grand = 0.0
    for r in rows:
        val = r["quantity"] * r["price"]
        grand += val
        cat_totals[r["category"]] = cat_totals.get(r["category"], 0) + val

    print(f"\n  {'Category':<20} {'Value (Rs)':>12}")
    print("  " + "-" * 35)
    for cat, val in sorted(cat_totals.items()):
        print(f"  {cat:<20} {val:>12.2f}")
    print("  " + "-" * 35)
    print(f"  {'GRAND TOTAL':<20} {grand:>12.2f}\n")

# ──────────────────────────────────────────────
#  8. CATEGORY SUMMARY
# ──────────────────────────────────────────────
def category_summary():
    header("CATEGORY-WISE SUMMARY")
    conn = get_conn()
    rows = conn.execute("""
        SELECT category,
               COUNT(*)          AS items,
               SUM(quantity)     AS total_qty,
               ROUND(SUM(quantity * price), 2) AS total_value
        FROM items GROUP BY category ORDER BY category
    """).fetchall()
    conn.close()

    print(f"\n  {'Category':<18} {'Items':>5} {'Total Qty':>10} {'Value (Rs)':>12}")
    print("  " + "-" * 50)
    for r in rows:
        print(f"  {r['category']:<18} {r['items']:>5} {r['total_qty']:>10} {r['total_value']:>12.2f}")
    print()

# ──────────────────────────────────────────────
#  9. EXPORT TO CSV
# ──────────────────────────────────────────────
def export_csv():
    header("EXPORT TO CSV")
    conn = get_conn()
    rows = conn.execute("SELECT * FROM items").fetchall()
    conn.close()
    filename = "inventory_export.csv"
    with open(filename, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Item ID", "Name", "Category", "Quantity", "Price", "Supplier", "Min Stock"])
        for r in rows:
            w.writerow([r["item_id"], r["name"], r["category"],
                        r["quantity"], r["price"], r["supplier"], r["min_stock"]])
    print(f"\n  [OK] Exported {len(rows)} records to '{filename}'\n")

# ──────────────────────────────────────────────
#  MAIN MENU
# ──────────────────────────────────────────────
MENU = """
+--------------------------------------------------+
|        INVENTORY MANAGEMENT SYSTEM               |
|   Alliance University - Python Micro Project     |
+--------------------------------------------------+
|  1. Add New Item                                 |
|  2. View All Items                               |
|  3. Search Item                                  |
|  4. Update Item                                  |
|  5. Delete Item                                  |
|--------------------------------------------------|
|  6. Low Stock Alerts                             |
|  7. Total Stock Valuation                        |
|  8. Category-wise Summary                        |
|  9. Export Inventory to CSV                      |
|--------------------------------------------------|
|  0. Exit                                         |
+--------------------------------------------------+
  Enter choice: """

ACTIONS = {
    "1": add_item,
    "2": view_all,
    "3": search_item,
    "4": update_item,
    "5": delete_item,
    "6": low_stock_alert,
    "7": stock_valuation,
    "8": category_summary,
    "9": export_csv,
}

def main():
    init_db()
    print("\n  Welcome to the Inventory Management System!")
    print("  Team: Navaneesh Reddy | Mohit | Chrysolite | Pavan R | Sai Sathwik\n")
    while True:
        choice = input(MENU).strip()
        if choice == "0":
            print("\n  Thank you! Goodbye.\n")
            break
        action = ACTIONS.get(choice)
        if action:
            action()
        else:
            print("  Invalid choice. Enter 0-9.")

if __name__ == "__main__":
    main()
